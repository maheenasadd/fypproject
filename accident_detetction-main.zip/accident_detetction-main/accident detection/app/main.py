import os
import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from app.routes.accident_detetction import router as accident_router
from app.routes.number_plate import plate_router as numberplate_router

load_dotenv()

app = FastAPI(
    title="Vehicle Detection API",
    description="API for detecting accidents and number plates in videos",
    version="1.0.0"
)

@app.on_event("startup")
async def startup_event():
    print("Starting Vehicle Detection API...")

# Create necessary directories
os.makedirs('uploads', exist_ok=True)
os.makedirs('results', exist_ok=True)

# Mount static files directory for viewing results
app.mount("/results", StaticFiles(directory="results"), name="results")

# Include routers
app.include_router(accident_router, prefix="/api/accident", tags=["Accident Detection"])
app.include_router(numberplate_router, prefix="/api/numberplate", tags=["Number Plate Detection"])

@app.get("/", tags=["Home"])
async def home():
    """API home endpoint"""
    return {
        "message": "Welcome to the Vehicle Detection API",
        "endpoints": {
            "accident_detection": [
                "/api/accident/analyze",
                "/api/accident/results/{task_id}",
                "/api/accident/video/{task_id}"
            ],
            "numberplate_detection": [
                "/api/numberplate/detect-video",
                "/api/numberplate/job-status/{job_id}",
                "/api/numberplate/results/{job_id}"
            ]
        }
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8005, reload=True)
