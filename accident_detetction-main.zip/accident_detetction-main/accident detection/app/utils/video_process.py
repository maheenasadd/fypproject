import cv2
import json
import numpy as np
from pathlib import Path
import pytesseract
import re
import os

# Global dictionary to store processing job information
processing_jobs = {}

def enhance_plate_image(plate_img):
    """Enhance license plate image for better OCR results"""
    # Convert to grayscale
    gray = cv2.cvtColor(plate_img, cv2.COLOR_BGR2GRAY)
    
    # Apply adaptive thresholding
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                  cv2.THRESH_BINARY_INV, 11, 2)
    
    # Apply morphological operations to clean the image
    kernel = np.ones((3, 3), np.uint8)
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
    
    # Invert back for OCR (black text on white background)
    result = cv2.bitwise_not(opening)
    
    # Resize for better OCR (keeping aspect ratio)
    height, width = result.shape
    new_width = 200  # Target width
    ratio = new_width / width
    new_height = int(height * ratio)
    resized = cv2.resize(result, (new_width, new_height), interpolation=cv2.INTER_CUBIC)
    
    return resized

def process_detection(frame, job_dir, frame_idx, detection, detection_idx, detections_in_frame):
    """Process a single detection"""
    # Get bounding box
    box = detection.boxes[0]  # Use first box if multiple are present
    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
    conf = float(box.conf[0])
    
    # Extract plate image for OCR
    plate_text = None
    if y2 > y1 and x2 > x1:  # Ensure valid dimensions
        # Expand the bounding box slightly to ensure complete plate capture
        height, width = frame.shape[:2]
        x1 = max(0, x1 - 5)
        y1 = max(0, y1 - 5)
        x2 = min(width, x2 + 5)
        y2 = min(height, y2 + 5)
        
        plate_img = frame[y1:y2, x1:x2].copy()
        
        # Save detected plate image
        plate_filename = f"plate_{frame_idx}_{detection_idx}.jpg"
        plate_path = job_dir / plate_filename
        cv2.imwrite(str(plate_path), plate_img)
        
        # Enhance image for better OCR results
        processed_img = enhance_plate_image(plate_img)
        
        # Save preprocessed image for debugging
        pre_path = job_dir / f"preproc_{frame_idx}_{detection_idx}.jpg"
        cv2.imwrite(str(pre_path), processed_img)
        
        # Set tesseract config for license plates
        custom_config = r'--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        try:
            # Try different preprocessing approaches if pytesseract is installed
            plate_text = pytesseract.image_to_string(processed_img, config=custom_config).strip()
            
            # If result is poor, try original image
            if len(plate_text) < 2:
                plate_text = pytesseract.image_to_string(plate_img, config=custom_config).strip()
                
            # Clean up the result (remove non-alphanumeric characters)
            plate_text = re.sub(r'[^A-Z0-9]', '', plate_text)
        except Exception as e:
            print(f"OCR error: {e}")
    
    # Add detection info
    detection_info = {
        "bbox": [float(x1), float(y1), float(x2), float(y2)],
        "confidence": float(conf),
        "frame_number": frame_idx,
        "plate_image": f"plate_{frame_idx}_{detection_idx}.jpg"
    }
    
    if plate_text and len(plate_text) >= 2:  # Only add if we have valid text
        detection_info["plate_text"] = plate_text
    
    detections_in_frame.append(detection_info)
    return plate_text

async def process_video(video_path: str, job_id: str, sample_rate: int = 1):
    """Process video and detect license plates"""
    # Import here to avoid circular import
    from app.utils.model_loader import get_model
    
    model = get_model()
    if model is None:
        processing_jobs[job_id] = {"status": "failed", "error": "Failed to load model"}
        return None
    
    try:
        # Get paths
        results_dir = Path("results")
        job_dir = results_dir / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        
        # Create a debug directory for problem diagnosis
        debug_dir = job_dir / "debug"
        debug_dir.mkdir(exist_ok=True)
        
        # Open video file
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            processing_jobs[job_id] = {"status": "failed", "error": "Could not open video file"}
            return None
            
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # Save some sample frames for debugging without detection
        frame_samples = [int(total_frames * fraction) for fraction in [0.1, 0.3, 0.5, 0.7, 0.9]]
        
        # Initialize job status
        processing_jobs[job_id] = {
            "status": "processing",
            "processed_frames": 0,
            "total_frames": total_frames,
            "detections_count": 0,
            "detections": []
        }
        
        frame_idx = 0
        all_detected_plates = []
        
        # Try multiple confidence thresholds to increase detection chances
        confidence_thresholds = [0.1, 0.05]  # Lower thresholds to catch more potential plates
        
        # Process frames (detection phase)
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            # Save sample frames for debugging
            if frame_idx in frame_samples:
                debug_frame_path = debug_dir / f"sample_frame_{frame_idx}.jpg"
                cv2.imwrite(str(debug_frame_path), frame)
                
                # Try all confidence values on sample frames and save results
                for conf_val in confidence_thresholds:
                    debug_results = model(frame, conf=conf_val)
                    # Draw boxes on debug image
                    debug_image = frame.copy()
                    for dr in debug_results:
                        for box in dr.boxes:
                            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                            conf = float(box.conf[0])
                            cv2.rectangle(debug_image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                            cv2.putText(debug_image, f"{conf:.2f}", (x1, y1-10), 
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                    
                    debug_result_path = debug_dir / f"debug_frame_{frame_idx}_conf_{conf_val}.jpg"
                    cv2.imwrite(str(debug_result_path), debug_image)
            
            # Process every nth frame according to sample rate
            if frame_idx % sample_rate == 0:
                # Apply preprocessing to improve detection
                processed_frame = frame.copy()
                
                # Try image enhancement techniques to improve detection
                # 1. Improve contrast
                lab = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2LAB)
                l, a, b = cv2.split(lab)
                clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
                cl = clahe.apply(l)
                limg = cv2.merge((cl, a, b))
                enhanced_frame = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
                
                # Try detection on original frame
                detections_in_frame = []
                found_in_original = False
                
                # Try with different confidence thresholds
                for conf_threshold in confidence_thresholds:
                    results = model(frame, conf=conf_threshold)
                    
                    # Process detections
                    for i, r in enumerate(results):
                        if len(r.boxes) > 0:
                            found_in_original = True
                            plate_text = process_detection(frame, job_dir, frame_idx, r, i, detections_in_frame)
                            if plate_text:
                                all_detected_plates.append(plate_text)
                    
                    if found_in_original:
                        break
                
                # If nothing found in original, try enhanced frame
                if not found_in_original:
                    for conf_threshold in confidence_thresholds:
                        results = model(enhanced_frame, conf=conf_threshold)
                        
                        # Process detections
                        for i, r in enumerate(results):
                            if len(r.boxes) > 0:
                                plate_text = process_detection(enhanced_frame, job_dir, frame_idx, r, i, detections_in_frame)
                                if plate_text:
                                    all_detected_plates.append(plate_text)
                
                # Update job status
                processing_jobs[job_id]["detections"].extend(detections_in_frame)
                processing_jobs[job_id]["detections_count"] += len(detections_in_frame)
                
                # Save frames with detections
                if len(detections_in_frame) > 0:
                    keyframe_path = job_dir / f"frame_{frame_idx}.jpg"
                    cv2.imwrite(str(keyframe_path), frame)
            
            # Update progress
            frame_idx += 1
            processing_jobs[job_id]["processed_frames"] = frame_idx
            
            # Print progress every 100 frames
            if frame_idx % 100 == 0:
                progress = (frame_idx / total_frames) * 100
                print(f"Processing video: {progress:.1f}% complete ({frame_idx}/{total_frames} frames)")
        
        # Close video after detection phase
        cap.release()
        
        # If no detections were found, try to identify why
        if processing_jobs[job_id]["detections_count"] == 0:
            print("No license plates detected. This could be due to:")
            print("1. No license plates in the video")
            print("2. License plates too small or unclear")
            print("3. Model not trained for this type of license plate")
            print("4. Check the debug directory for sample frames for manual inspection")
            
            # Add diagnostics to job info
            processing_jobs[job_id]["warning"] = "No license plates detected. Check debug directory for sample frames."
        
        # Save detection data to JSON
        detections_path = job_dir / "detections.json"
        with open(str(detections_path), "w") as f:
            json.dump(processing_jobs[job_id]["detections"], f)
        
        # Create dictionary with unique plate texts
        unique_plates = {}
        for detection in processing_jobs[job_id]["detections"]:
            if "plate_text" in detection:
                plate_text = detection["plate_text"]
                if plate_text not in unique_plates:
                    unique_plates[plate_text] = detection["frame_number"]
        
        # Now process the video again to create annotated output
        from app.utils.plate_processor import process_license_plate_video
        
        # Process the video with our detections
        output_path = str(job_dir / "output.mp4")
        process_license_plate_video(
            video_path, 
            processing_jobs[job_id], 
            output_path
        )
        
        # Update job status
        processing_jobs[job_id]["status"] = "completed"
        processing_jobs[job_id]["plate_numbers"] = list(unique_plates.keys())
        processing_jobs[job_id]["total_unique_plates"] = len(unique_plates)
        processing_jobs[job_id]["output_video_path"] = output_path
        processing_jobs[job_id]["debug_directory"] = str(debug_dir)
        
        return list(unique_plates.keys())
        
    except Exception as e:
        import traceback
        print(f"Error processing video: {e}")
        print(traceback.format_exc())
        processing_jobs[job_id]["status"] = "failed"
        processing_jobs[job_id]["error"] = str(e)
        return None

def get_job_status(job_id: str):
    """Get the status of a video processing job"""
    if job_id not in processing_jobs:
        return None
    return processing_jobs[job_id]

def delete_job(job_id: str):
    """Remove a job from the processing jobs dictionary"""
    if job_id in processing_jobs:
        del processing_jobs[job_id]
        return True
    return False