import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import logging
from datetime import datetime

# Set up logging for email operations
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("email_service.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('email_service')

class EmailService:
    def __init__(self):
        # Email configuration with fallback values
        self.smtp_server = os.environ.get('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.environ.get('SMTP_PORT', 465))  # Default to SSL
        self.email_sender = os.environ.get('EMAIL_SENDER_ADDRESS', 'asadjaved6299@gmail.com')
        self.email_password = os.environ.get('SMTP_PASSWORD', 'reme gpqo trlv sjcp')
        self.use_ssl = self.smtp_port == 465
        
        # Log configuration (without password)
        logger.info(f"Email service initialized with: server={self.smtp_server}, port={self.smtp_port}, sender={self.email_sender}, use_ssl={self.use_ssl}")
        
    def send_email(self, recipient_email, subject, html_content, text_content=None):
        """
        Generic email sending function that handles both SSL and TLS connections
        """
        if not text_content:
            text_content = "This email requires HTML support to view properly."
            
        try:
            # Create the email message
            message = MIMEMultipart('alternative')
            message['From'] = self.email_sender
            message['To'] = recipient_email
            message['Subject'] = subject
            
            # Attach text and HTML parts
            message.attach(MIMEText(text_content, 'plain'))
            message.attach(MIMEText(html_content, 'html'))
            
            logger.info(f"Attempting to send email to {recipient_email} with subject: {subject}")
            
            # Choose connection method based on port
            if self.use_ssl:
                # Use SSL connection
                try:
                    server = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
                    logger.info("Connected using SSL")
                    server.login(self.email_sender, self.email_password)
                    server.send_message(message)
                    server.quit()
                    logger.info(f"Email successfully sent to {recipient_email} using SSL")
                    return True
                except Exception as e:
                    logger.error(f"SSL email sending failed: {e}")
                    # Fall back to TLS if SSL fails
                    logger.info("Falling back to TLS method...")
                    self.use_ssl = False
                    self.smtp_port = 587
            
            # TLS connection (used as fallback or primary depending on port)
            if not self.use_ssl:
                with smtplib.SMTP(self.smtp_server, 587) as server:
                    server.ehlo()
                    server.starttls()
                    server.ehlo()
                    server.login(self.email_sender, self.email_password)
                    server.send_message(message)
                    logger.info(f"Email successfully sent to {recipient_email} using TLS")
                    return True
                    
        except Exception as e:
            logger.error(f"Failed to send email to {recipient_email}: {e}")
            return False
    
    def send_emergency_alert(self, recipient_email, accident_details):
        """
        Send emergency email alert with accident details
        """
        # Format the accident details
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        accident_count = accident_details.get('accidents_count', 0)
        timestamps = accident_details.get('timestamps', [])
        confidence = accident_details.get('confidence_scores', [])
        accident_types = accident_details.get('accident_types', [])
        
        # Build the HTML email body
        html_body = f"""
        <html>
        <body>
            <h2 style="color: #FF0000;">EMERGENCY ALERT: Vehicle Accident Detected</h2>
            <p><strong>Time of Alert:</strong> {current_time}</p>
            <p><strong>Accidents Detected:</strong> {accident_count}</p>
            
            <h3>Accident Details:</h3>
            <table border="1" cellpadding="5" style="border-collapse: collapse;">
                <tr>
                    <th>Timestamp (seconds)</th>
                    <th>Confidence</th>
                    <th>Accident Type</th>
                </tr>
        """
        
        # Build the plain text email body
        text_body = f"""
        EMERGENCY ALERT: Vehicle Accident Detected
        Time of Alert: {current_time}
        Accidents Detected: {accident_count}
        
        Accident Details:
        """
        
        # Add each accident to both formats
        for i in range(len(timestamps)):
            timestamp = timestamps[i] if i < len(timestamps) else "N/A"
            conf = f"{confidence[i] * 100:.1f}%" if i < len(confidence) and confidence[i] is not None else "N/A"
            
            # Handle different accident_types data structures
            if i < len(accident_types):
                if isinstance(accident_types[i], list):
                    types = ", ".join(accident_types[i])
                else:
                    types = str(accident_types[i])
            else:
                types = "Unknown"
            
            html_body += f"""
                <tr>
                    <td>{timestamp}</td>
                    <td>{conf}</td>
                    <td>{types}</td>
                </tr>
            """
            
            text_body += f"""
            - Timestamp: {timestamp} seconds
            - Confidence: {conf}
            - Accident Type: {types}
            """
        
        html_body += """
            </table>
            
            <p style="color: #FF0000; font-weight: bold;">
                This is an automated emergency alert. Please contact emergency services immediately if this alert is valid.
            </p>
            
            <p>
                <small>This message was sent automatically by the Accident Detection System.</small>
            </p>
        </body>
        </html>
        """
        
        text_body += """
        
        This is an automated emergency alert. Please contact emergency services immediately if this alert is valid.
        This message was sent automatically by the Accident Detection System.
        """
        
        # Send the email using the generic send function
        subject = f"⚠️ EMERGENCY: Accident Detected! ({accident_count} incidents)"
        return self.send_email(recipient_email, subject, html_body, text_body)


# Singleton instance for easy import
email_service = EmailService()