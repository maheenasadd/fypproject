import cv2
import numpy as np
import json
import os
from pathlib import Path

def process_license_plate_video(input_path, detection_results, output_path):
    """
    Process the video by adding annotations for detected license plates
    
    Args:
        input_path: Path to the input video
        detection_results: Results from the license plate detector
        output_path: Path where the processed video will be saved
    """
    print(f"Starting video processing with annotations: {input_path} -> {output_path}")
    
    # Open the input video
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        print(f"Error: Could not open video file {input_path}")
        return None
    
    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    print(f"Video properties: {width}x{height}, {fps} fps, {total_frames} frames")
    
    # Set up video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    if not out.isOpened():
        print(f"Error: Could not create output video file {output_path}")
        cap.release()
        return None
    
    # Create a dictionary to map frame numbers to detections
    frame_detections = {}
    for detection in detection_results.get("detections", []):
        frame_num = detection["frame_number"]
        if frame_num not in frame_detections:
            frame_detections[frame_num] = []
        frame_detections[frame_num].append(detection)
    
    # Process each frame
    frame_count = 0
    
    # Create a list to store unique license plates for summary
    unique_plates = {}  # Map plate text to first frame where it was detected
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Check if current frame has any license plate detections
        if frame_count in frame_detections:
            detections = frame_detections[frame_count]
            
            # Add a header notification bar
            notification_height = 40
            notification_bar = np.zeros((notification_height, width, 3), dtype=np.uint8)
            notification_bar[:, :] = (0, 122, 204)  # Blue notification bar
            
            # Add text to notification bar
            cv2.putText(
                notification_bar,
                f"LICENSE PLATE(S) DETECTED: {len(detections)}",
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (255, 255, 255),
                2
            )
            
            # Attach notification bar to the top of the frame
            frame_with_bar = np.vstack([notification_bar, frame])
            # Resize back to original dimensions
            frame_with_bar = cv2.resize(frame_with_bar, (width, height))
            frame = frame_with_bar
            
            # Process each detection in this frame
            for detection in detections:
                # Get bounding box
                x1, y1, x2, y2 = [int(coord) for coord in detection["bbox"]]
                
                # Draw bounding box with thick red border
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 3)
                
                # Check if we have plate text
                if "plate_text" in detection and detection["plate_text"]:
                    plate_text = detection["plate_text"]
                    confidence = detection["confidence"]
                    
                    # Add plate text to unique plates dict
                    if plate_text not in unique_plates:
                        unique_plates[plate_text] = frame_count
                    
                    # Create background for text
                    text = f"Plate: {plate_text}"
                    text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
                    
                    # Draw semi-transparent background
                    overlay = frame.copy()
                    cv2.rectangle(
                        overlay,
                        (x1, y1 - text_size[1] - 10),
                        (x1 + text_size[0] + 10, y1),
                        (0, 0, 0),
                        -1
                    )
                    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
                    
                    # Add plate text
                    cv2.putText(
                        frame,
                        text,
                        (x1 + 5, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )
                    
                    # Add confidence score
                    conf_text = f"Conf: {confidence:.2f}"
                    cv2.putText(
                        frame,
                        conf_text,
                        (x2 - 100, y2 + 25),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6,
                        (255, 255, 0),
                        2
                    )
        
        # Add frame counter and timestamp to all frames
        timestamp = frame_count / fps
        cv2.putText(
            frame,
            f"Frame: {frame_count} | Time: {timestamp:.2f}s",
            (10, height - 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )
        
        # Write the frame
        out.write(frame)
        frame_count += 1
        
        # Print progress every 100 frames
        if frame_count % 100 == 0:
            print(f"Processing: {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
    
    # Add a summary frame at the end
    if unique_plates:
        for _ in range(int(fps * 5)):  # 5 seconds of summary
            summary_frame = np.zeros((height, width, 3), dtype=np.uint8)
            
            # Add heading
            cv2.putText(
                summary_frame,
                "DETECTED LICENSE PLATES",
                (width // 4, 60),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.2,
                (255, 255, 255),
                2
            )
            
            # Add detected plates
            y_offset = 120
            for i, (plate_text, first_frame) in enumerate(unique_plates.items()):
                first_timestamp = first_frame / fps
                
                cv2.putText(
                    summary_frame,
                    f"{i+1}. {plate_text} (First seen at {first_timestamp:.2f}s)",
                    (width // 6, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 255, 0),
                    2
                )
                y_offset += 50
                
                if y_offset > height - 50:  # Prevent text from going off screen
                    break
            
            out.write(summary_frame)
    
    # Release resources
    cap.release()
    out.release()
    
    print(f"License plate video processing complete: {output_path}")
    
    # Update results with the video path
    detection_results["video_result_path"] = output_path
    
    return output_path