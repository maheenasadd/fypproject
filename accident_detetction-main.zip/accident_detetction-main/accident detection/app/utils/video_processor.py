
import cv2
import numpy as np
import json
import os
from pathlib import Path

def process_video(input_path, detection_results, output_path):
    """
    Process the video by adding annotations for detected accidents
    
    Args:
        input_path: Path to the input video
        detection_results: Results from the accident detector
        output_path: Path where the processed video will be saved
    """
    # Open the input video
    cap = cv2.VideoCapture(input_path)
    
    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    # Set up video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    # Create markers for accident timestamps
    accident_frames = []
    for timestamp in detection_results.get("timestamps", []):
        frame_num = int(timestamp * fps)
        accident_frames.append(frame_num)
    
    # Process each frame
    frame_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Check if current frame is near an accident timestamp
        is_accident_frame = any(abs(frame_count - af) < 30 for af in accident_frames)
        accident_index = next((i for i, af in enumerate(accident_frames) 
                              if abs(frame_count - af) < 30), None)
        
        # Add annotations if this is an accident frame
        if is_accident_frame and accident_index is not None:
            # Add a red border to indicate accident
            cv2.rectangle(frame, (0, 0), (width, height), (0, 0, 255), 10)
            
            # Add text with accident type and confidence
            confidence = detection_results["confidence_scores"][accident_index]
            accident_types = ", ".join(detection_results["accident_types"][accident_index])
            
            text = f"ACCIDENT DETECTED! Type: {accident_types}, Conf: {confidence:.2f}"
            
            # Create background for text
            text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
            cv2.rectangle(
                frame, 
                (10, 30 - text_size[1] - 10), 
                (10 + text_size[0] + 10, 30 + 10), 
                (0, 0, 0), 
                -1
            )
            
            # Add text
            cv2.putText(
                frame, 
                text,
                (15, 25), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                1, 
                (255, 255, 255), 
                2
            )
        
        # Add timestamp to all frames
        timestamp = frame_count / fps
        cv2.putText(
            frame,
            f"Time: {timestamp:.2f}s", 
            (width - 200, height - 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )
        
        # Write the frame
        out.write(frame)
        frame_count += 1
        
        # Print progress every 100 frames
        if frame_count % 100 == 0:
            print(f"Processing: {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
    
    # Release resources
    cap.release()
    out.release()
    
    print(f"Video processing complete: {output_path}")
    
    # Update results with the video path
    detection_results["video_result_path"] = output_path
    
    return output_path