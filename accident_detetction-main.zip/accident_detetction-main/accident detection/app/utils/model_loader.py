from pathlib import Path
import os
import torch
import cv2
import numpy as np
from ultralytics import YOLO

# Initialize model cache
_model = None
MODEL_PATH = Path(r"D:\accident detection\numberplate_detction.pt")
def get_model():
    """
    Load and return the YOLOv8 license plate detection model
    """
    global _model
    
    if _model is not None:
        return _model
    
    try:
        # Get the model path - change this to the actual path where your model is stored
        model_dir = Path("models")
        model_dir.mkdir(exist_ok=True)
        
        # Look for any .pt files in the models directory
        model_files = list(model_dir.glob("*.pt"))
        
        if not model_files:
            print("No model files found in the models directory.")
            print("Attempting to use the default YOLOv8n model...")
            try:
                # Try to use a general-purpose YOLOv8 model
                _model = YOLO("yolov8n.pt")
                print("Using default YOLOv8n model. Note: This model is not specifically trained for license plates.")
                return _model
            except Exception as e:
                print(f"Error loading default model: {e}")
                return None
        
        # Use the first model file found
        model_path = model_files[0]
        print(f"Loading model from: {model_path}")
        
        # Load the YOLO model
        _model = YOLO(str(model_path))
        
        # Set model parameters for better license plate detection
        # Some models may need class filtering if they detect multiple classes
        _model.conf = 0.1  # Lower confidence threshold to increase detection chance
        _model.iou = 0.5   # Intersection over Union threshold
        
        # Check if the model has classes and if license plate is one of them
        if hasattr(_model, 'names') and _model.names:
            class_names = _model.names
            print(f"Model classes: {class_names}")
            
            # If the model has a license plate class, filter to only that class
            license_plate_classes = []
            for class_id, class_name in class_names.items():
                if "plate" in class_name.lower() or "license" in class_name.lower():
                    license_plate_classes.append(class_id)
            
            if license_plate_classes:
                print(f"Found license plate classes: {license_plate_classes}")
                # Set the model to only detect these classes
                # Note: This might need adjustment based on your specific model
                _model.classes = license_plate_classes
        
        print("Model loaded successfully!")
        return _model
        
    except Exception as e:
        import traceback
        print(f"Error loading model: {e}")
        print(traceback.format_exc())
        return None

def test_model_on_image(image_path):
    """
    Test the model on a sample image to verify it can detect license plates
    
    Args:
        image_path: Path to a test image
    
    Returns:
        True if detection successful, False otherwise
    """
    model = get_model()
    if model is None:
        return False
    
    if not os.path.exists(image_path):
        print(f"Test image not found: {image_path}")
        return False
    
    image = cv2.imread(image_path)
    if image is None:
        print(f"Could not read test image: {image_path}")
        return False
    
    results = model(image, conf=0.1)  # Lower threshold for testing
    
    # Check if any detections were made
    for r in results:
        if len(r.boxes) > 0:
            print(f"Model successfully detected {len(r.boxes)} objects in test image")
            return True
    
    print("No detections made on test image. Model might not be working correctly.")
    return False
def load_model():
    """Load the YOLOv8 model"""
    global model
    if model is None:
        try:
            # Check if model exists
            if not MODEL_PATH.exists():
                print(f"Error: Model file not found at {MODEL_PATH}")
                return False
            
            # Import Ultralytics YOLO
            try:
                from ultralytics import YOLO
            except ImportError:
                print("Error: ultralytics package not installed. Please install it with: pip install ultralytics")
                return False
            
            # Load YOLOv8 model
            model = YOLO(str(MODEL_PATH))
            print(f"YOLOv8 number plate detection model loaded successfully from {MODEL_PATH}")
            return True
        except Exception as e:
            print(f"Error loading YOLOv8 model: {e}")
            return False
    return True
