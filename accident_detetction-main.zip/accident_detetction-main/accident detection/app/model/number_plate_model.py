from typing import List, Optional
from pydantic import BaseModel

class Detection(BaseModel):
    bbox: List[float]
    confidence: float
    plate_text: Optional[str] = None
    frame_number: int
    plate_image: Optional[str] = None

class VideoProcessResponse(BaseModel):
    job_id: str
    message: str

class JobStatus(BaseModel):
    job_id: str
    status: str
    processed_frames: int = 0
    total_frames: int = 0
    detections_count: int = 0
    progress_percentage: Optional[int] = None
    error: Optional[str] = None

class JobResults(BaseModel):
    job_id: str
    status: str
    output_video: Optional[str] = None
    detections_json: Optional[str] = None
    detection_count: int = 0
    keyframes: List[str] = []
    plate_images: Optional[List[str]] = []
    detected_plates: Optional[List[str]] = []
    unique_plates_count: Optional[int] = 0
    message: Optional[str] = None