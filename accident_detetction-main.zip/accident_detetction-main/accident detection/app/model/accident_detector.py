import torch
import cv2
import numpy as np
import librosa
from pathlib import Path
import tempfile
import os
import time

class AccidentDetector:
    def __init__(self, model_path):
        """
        Initialize the accident detector with a pre-trained YOLO model
        
        Args:
            model_path: Path to the pre-trained YOLO model (best(1).pt)
        """
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load the YOLO model
        self.model = self.load_model(model_path)
        
        # Define accident related classes (based on your model)
        self.accident_classes = [0]  # Assuming class 0 is 'accident' in your model
        
        # Configurable detection thresholds
        self.visual_detection_threshold = 0.5  # Threshold for YOLO detection confidence
        self.audio_detection_thresholds = {
            "brake_sound": 0.7,
            "glass_break": 0.8,
            "impact_sound": 0.4
        }
        
        # Accident severity levels (can be used for prioritization)
        self.severity_thresholds = {
            "low": 0.5,    # Minor incidents
            "medium": 0.7, # Moderate accidents
            "high": 0.85   # Severe accidents
        }
        
        print(f"Accident detection model loaded on {self.device}")
    
    def load_model(self, model_path):
        """Load the YOLO model from the specified path"""
        # SOLUTION: Directly load the model with weights_only=False
        # This is the most reliable method when you trust your model source
        try:
            print("Loading model with weights_only=False (trusted source method)")
            model = torch.load(model_path, map_location=self.device, weights_only=False)
            
            # Extract model from checkpoint if needed
            if isinstance(model, dict) and 'model' in model:
                model = model['model']
                
            model = model.float().to(self.device)
            model.eval()
            return model
            
        except Exception as e:
            print(f"Error loading model with weights_only=False: {e}")
            
            # Try alternative method with safe_globals - correct syntax for PyTorch 2.0+
            try:
                print("Trying safe_globals method")
                # First check PyTorch version
                torch_version = torch.__version__
                major_version = int(torch_version.split('.')[0])
                minor_version = int(torch_version.split('.')[1])
                
                # Different approach based on PyTorch version
                if major_version >= 2:
                    # For PyTorch 2.x
                    from torch.serialization import safe_globals
                    
                    # Load with safe_globals context manager
                    with safe_globals():
                        model = torch.load(model_path, map_location=self.device)
                        
                        # Extract model from checkpoint if needed
                        if isinstance(model, dict) and 'model' in model:
                            model = model['model']
                            
                        model = model.float().to(self.device)
                        model.eval()
                        return model
                else:
                    # For older PyTorch versions
                    model = torch.load(model_path, map_location=self.device)
                    
                    # Extract model from checkpoint if needed
                    if isinstance(model, dict) and 'model' in model:
                        model = model['model']
                        
                    model = model.float().to(self.device)
                    model.eval()
                    return model
                    
            except Exception as e2:
                print(f"Error with safe_globals approach: {e2}")
                
                # As a final fallback, try loading as jit model
                try:
                    print("Trying to load model as TorchScript/JIT model")
                    model = torch.jit.load(model_path, map_location=self.device)
                    model.eval()
                    return model
                except Exception as e3:
                    error_message = f"""
                    All model loading methods failed.
                    Try installing required dependencies:
                    1. pip install pandas
                    2. pip install ultralytics
                    
                    Or use torch.load with weights_only=False in your code if you trust the model source.
                    
                    Final error: {e3}
                    """
                    raise Exception(error_message)
    
    def detect_accidents(self, video_path):
        """
        Process a video for accident detection
        
        Args:
            video_path: Path to the input video file
        
        Returns:
            Dict containing detection results
        """
        # Initialize results dictionary
        results = {
            "accidents_detected": False,
            "accidents_count": 0,
            "timestamps": [],
            "confidence_scores": [],
            "accident_types": [],
            "severity_levels": [],  # Added severity estimation
            "detection_summary": {}  # Added summary statistics
        }
        
        # Check if the file exists
        if not os.path.exists(video_path):
            raise FileNotFoundError(f"Video file not found: {video_path}")
        
        # Extract audio for sound analysis
        audio_features = self._extract_audio_features(video_path)
        
        # Process video frames
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise IOError(f"Could not open video file: {video_path}")
            
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        frame_count = 0
        
        # Tracking variables for accident detection
        consecutive_detections = 0
        detected_frames = []
        max_confidence = 0.0
        
        print(f"Processing video with {total_frames} frames at {fps} FPS")
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Process every 5th frame to speed up analysis
            if frame_count % 5 == 0:
                # Calculate current timestamp
                timestamp = frame_count / fps
                
                # YOLO detection on the frame
                visual_detection = self._detect_with_yolo(frame)
                
                # Check audio features around this timestamp
                audio_detection = self._analyze_audio_at_timestamp(audio_features, timestamp)
                
                # Determine if this frame contains an accident
                frame_has_accident = visual_detection["detected"] or audio_detection["detected"]
                
                # Calculate combined confidence score
                confidence = max(
                    visual_detection["confidence"], 
                    audio_detection["confidence"]
                )
                
                # Track consecutive detections to reduce false positives
                if frame_has_accident:
                    consecutive_detections += 1
                    detected_frames.append(frame_count)
                    max_confidence = max(max_confidence, confidence)
                else:
                    # Reset consecutive counter if gap is too large
                    if consecutive_detections < 3:  # Less than 3 consecutive detections
                        consecutive_detections = 0
                
                # Confident accident detection
                if frame_has_accident and (confidence > 0.7 or consecutive_detections >= 3):
                    # Determine if this is a new accident or continuation
                    is_new_accident = True
                    
                    # Check if this detection is close to the last recorded accident
                    if results["timestamps"] and (timestamp - results["timestamps"][-1]) < 3.0:
                        # This is likely the same accident continuing (within 3 seconds)
                        is_new_accident = False
                        
                        # Update the confidence if this detection is more confident
                        if confidence > results["confidence_scores"][-1]:
                            results["confidence_scores"][-1] = round(confidence, 2)
                    
                    if is_new_accident:
                        results["accidents_detected"] = True
                        results["accidents_count"] += 1
                        results["timestamps"].append(round(timestamp, 2))
                        results["confidence_scores"].append(round(confidence, 2))
                        
                        # Determine accident type
                        accident_type = []
                        if visual_detection["detected"]:
                            accident_type.append("visual_collision")
                        if audio_detection["detected"]:
                            accident_type.extend(audio_detection["types"])
                        
                        results["accident_types"].append(accident_type)
                        
                        # Estimate accident severity
                        severity = self._estimate_severity(confidence, visual_detection, audio_detection)
                        results["severity_levels"].append(severity)
                
            frame_count += 1
            
            # Print progress for long videos
            if frame_count % 1000 == 0:
                print(f"Processed {frame_count}/{total_frames} frames ({frame_count/total_frames*100:.1f}%)")
        
        cap.release()
        
        # Add detection summary
        results["detection_summary"] = {
            "total_frames_analyzed": frame_count,
            "total_frames_with_detections": len(detected_frames),
            "detection_rate": len(detected_frames) / frame_count if frame_count > 0 else 0,
            "average_confidence": sum(results["confidence_scores"]) / len(results["confidence_scores"]) if results["confidence_scores"] else 0,
            "max_confidence": max(results["confidence_scores"]) if results["confidence_scores"] else 0,
            "video_duration_seconds": frame_count / fps if fps > 0 else 0
        }
        
        return results
    
    def _detect_with_yolo(self, frame):
        """Detect accidents in a single frame using YOLO"""
        result = {"detected": False, "confidence": 0.0, "boxes": []}
        
        try:
            # Resize image for model
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Handle different possible model interfaces
            
            # Approach 1: Try standard YOLO inference
            try:
                if hasattr(self.model, 'forward'):
                    # Standard PyTorch model
                    with torch.no_grad():
                        # Convert image to tensor
                        img_tensor = torch.from_numpy(img).float()
                        img_tensor = img_tensor.permute(2, 0, 1).unsqueeze(0) / 255.0  # HWC to BCHW and normalize
                        img_tensor = img_tensor.to(self.device)
                        
                        # Run detection
                        detections = self.model(img_tensor)
                        
                elif hasattr(self.model, 'predict'):
                    # For models with predict() method
                    detections = self.model.predict(img)
                    
                else:
                    # Try call interface
                    detections = self.model(img)
            
                # Process detections - we need to handle different formats
                if isinstance(detections, list) and len(detections) > 0:
                    # Handle list format
                    for detection in detections:
                        if hasattr(detection, 'xyxy'):
                            # YOLOv5 Results format
                            for *box, conf, cls in detection.xyxy[0].cpu().numpy():
                                class_id = int(cls)
                                confidence = float(conf)
                                
                                if class_id in self.accident_classes and confidence > self.visual_detection_threshold:
                                    result["detected"] = True
                                    result["confidence"] = max(result["confidence"], confidence)
                                    result["boxes"].append({
                                        "box": [float(x) for x in box],
                                        "confidence": confidence
                                    })
                
                elif hasattr(detections, 'xyxy'):
                    # YOLOv5 Results format directly
                    for *box, conf, cls in detections.xyxy[0].cpu().numpy():
                        class_id = int(cls)
                        confidence = float(conf)
                        
                        if class_id in self.accident_classes and confidence > self.visual_detection_threshold:
                            result["detected"] = True
                            result["confidence"] = max(result["confidence"], confidence)
                            result["boxes"].append({
                                "box": [float(x) for x in box],
                                "confidence": confidence
                            })
                
                elif isinstance(detections, torch.Tensor) and detections.dim() == 3:
                    # Handle tensor output format (n, detections, 6)
                    # Format: [x1, y1, x2, y2, confidence, class]
                    detections_np = detections.cpu().numpy()
                    for i in range(detections_np.shape[1]):
                        detection = detections_np[0, i]
                        if len(detection) >= 6:  # Make sure we have complete detection
                            box = detection[:4]
                            confidence = float(detection[4])
                            class_id = int(detection[5])
                            
                            if class_id in self.accident_classes and confidence > self.visual_detection_threshold:
                                result["detected"] = True
                                result["confidence"] = max(result["confidence"], confidence)
                                result["boxes"].append({
                                    "box": [float(x) for x in box],
                                    "confidence": confidence
                                })
                
                elif isinstance(detections, tuple) and len(detections) >= 2:
                    # Some models return (boxes, scores, classes) or similar
                    boxes, scores = detections[0], detections[1]
                    classes = detections[2] if len(detections) > 2 else None
                    
                    for i in range(len(boxes)):
                        box = boxes[i]
                        confidence = float(scores[i])
                        class_id = int(classes[i]) if classes is not None else 0
                        
                        if class_id in self.accident_classes and confidence > self.visual_detection_threshold:
                            result["detected"] = True
                            result["confidence"] = max(result["confidence"], confidence)
                            result["boxes"].append({
                                "box": [float(x) for x in box],
                                "confidence": confidence
                            })
                
                else:
                    print(f"Warning: Unknown detection format: {type(detections)}")
                    
            except Exception as inner_e:
                print(f"First detection method failed: {inner_e}")
                
                # Fallback method: check if model has specific fields indicating YOLOv5 structure
                try:
                    if hasattr(self.model, 'names') and hasattr(self.model, 'model'):
                        # Try accessing YOLOv5 model structure
                        print("Model appears to be YOLOv5 structure, using direct inference")
                        
                        # Resize and prepare image according to YOLOv5 format
                        img_size = 640  # Standard YOLOv5 input size
                        img_resized = cv2.resize(img, (img_size, img_size))
                        img_tensor = torch.from_numpy(img_resized).float()
                        img_tensor = img_tensor.permute(2, 0, 1).unsqueeze(0) / 255.0
                        img_tensor = img_tensor.to(self.device)
                        
                        # Run inference
                        with torch.no_grad():
                            output = self.model(img_tensor)
                            
                        # Process output (assuming standard YOLOv5 output format)
                        # Output is typically [batch, num_detections, 6] where last dim is [x1, y1, x2, y2, conf, cls]
                        if isinstance(output, torch.Tensor) and output.dim() >= 2:
                            for detection in output[0]:
                                if len(detection) >= 6:  # Make sure we have complete detection
                                    box = detection[:4].tolist()
                                    confidence = float(detection[4])
                                    class_id = int(detection[5])
                                    
                                    if class_id in self.accident_classes and confidence > self.visual_detection_threshold:
                                        result["detected"] = True
                                        result["confidence"] = max(result["confidence"], confidence)
                                        result["boxes"].append({
                                            "box": box,
                                            "confidence": confidence
                                        })
                except Exception as e2:
                    print(f"Fallback detection method also failed: {e2}")
                    
        except Exception as e:
            print(f"Error during detection: {e}")
        
        return result
    
    def _extract_audio_features(self, video_path):
        """Extract audio from video and compute features for analysis"""
        try:
            # Extract audio to temporary file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_audio:
                temp_audio_path = temp_audio.name
            
            # Check if ffmpeg is available
            import shutil
            if shutil.which('ffmpeg') is None:
                print("Warning: ffmpeg not found in PATH. Audio analysis will be skipped.")
                return None
                
            # Extract audio with ffmpeg
            ffmpeg_cmd = f"ffmpeg -i \"{video_path}\" -q:a 0 -map a \"{temp_audio_path}\" -y -hide_banner -loglevel error"
            exit_code = os.system(ffmpeg_cmd)
            
            if exit_code != 0:
                print(f"Error extracting audio with ffmpeg (exit code: {exit_code})")
                return None
            
            # Check if the audio file exists and has content
            if not os.path.exists(temp_audio_path) or os.path.getsize(temp_audio_path) == 0:
                print("Error: No audio track found or audio extraction failed")
                return None
            
            # Load audio file
            try:
                y, sr = librosa.load(temp_audio_path, sr=None)
            except Exception as e:
                print(f"Error loading audio with librosa: {e}")
                return None
            
            # Compute features
            features = {
                "waveform": y,
                "sample_rate": sr,
                # Compute mel-spectrogram for sound event detection
                "mel_spec": librosa.feature.melspectrogram(y=y, sr=sr),
                # Compute spectral contrast for detecting sudden changes
                "contrast": librosa.feature.spectral_contrast(y=y, sr=sr),
                # Onset strength for detecting sudden sounds
                "onset": librosa.onset.onset_strength(y=y, sr=sr),
                # Root mean square energy
                "rms": librosa.feature.rms(y=y)[0]
            }
            
            # Clean up
            try:
                os.unlink(temp_audio_path)
            except Exception as e:
                print(f"Warning: Failed to delete temporary audio file: {e}")
            
            return features
            
        except Exception as e:
            print(f"Error extracting audio features: {e}")
            return None
    
    def _analyze_audio_at_timestamp(self, audio_features, timestamp):
        """Analyze audio features at a specific timestamp for accident sounds"""
        result = {"detected": False, "confidence": 0.0, "types": []}
        
        if audio_features is None:
            return result
            
        # Convert timestamp to frame index in audio features
        sr = audio_features["sample_rate"]
        frame_idx = int(timestamp * sr)
        
        # Safety check to ensure we're within bounds
        if frame_idx >= len(audio_features["waveform"]):
            return result
        
        # Define window size (e.g., 0.5 second window)
        window_size = int(0.5 * sr)
        start_idx = max(0, frame_idx - window_size // 2)
        end_idx = min(len(audio_features["waveform"]), frame_idx + window_size // 2)
        
        # Extract audio segment
        segment = audio_features["waveform"][start_idx:end_idx]
        
        # 1. Check for sudden braking/tire skid - characteristic high frequency content
        # Look for high spectral contrast and high onset strength
        segment_frame = frame_idx // 512  # Adjust based on your feature extraction parameters
        if segment_frame < audio_features["contrast"].shape[1]:
            contrast = np.mean(audio_features["contrast"][:, segment_frame])
            if contrast > self.audio_detection_thresholds["brake_sound"]:
                result["detected"] = True
                result["confidence"] = max(result["confidence"], contrast)
                result["types"].append("tire_skid")
        
        # 2. Check for glass breaking - characterized by sudden high-frequency burst
        if len(segment) > 0:
            # Compute short-time energy
            energy = np.sum(segment**2) / len(segment)
            # Check for high energy transients
            if energy > 0.05:  # Threshold can be tuned
                spectral_centroid = librosa.feature.spectral_centroid(y=segment, sr=sr)[0]
                # Glass breaking typically has high spectral centroid
                if np.mean(spectral_centroid) > 3000:
                    result["detected"] = True
                    result["confidence"] = max(result["confidence"], min(1.0, energy * 10))
                    result["types"].append("glass_breaking")
        
        # 3. Check for crash sounds - characterized by sudden loud sounds
        rms_idx = min(frame_idx // 512, len(audio_features["rms"]) - 1)
        if rms_idx >= 0:
            rms = audio_features["rms"][rms_idx]
            # Look for peaks in RMS energy
            if rms > self.audio_detection_thresholds["impact_sound"]:
                result["detected"] = True
                result["confidence"] = max(result["confidence"], min(1.0, rms * 2))
                result["types"].append("impact_sound")
        
        return result
    
    def _estimate_severity(self, confidence, visual_detection, audio_detection):
        """
        Estimate the severity of the detected accident
        
        Args:
            confidence: Overall detection confidence
            visual_detection: Visual detection results
            audio_detection: Audio detection results
            
        Returns:
            String indicating severity: "low", "medium", or "high"
        """
        # Start with base severity based on confidence
        if confidence >= self.severity_thresholds["high"]:
            severity = "high"
        elif confidence >= self.severity_thresholds["medium"]:
            severity = "medium"
        else:
            severity = "low"
        
        # Increase severity if multiple detection types
        detection_types = []
        if visual_detection["detected"]:
            detection_types.append("visual")
        if audio_detection["detected"] and "impact_sound" in audio_detection["types"]:
            detection_types.append("impact")
        if audio_detection["detected"] and "glass_breaking" in audio_detection["types"]:
            detection_types.append("glass")
        
        # If we have multiple detection types, increase severity
        if len(detection_types) >= 2:
            if severity == "low":
                severity = "medium"
            elif severity == "medium":
                severity = "high"
        
        # If we have glass breaking detection with high confidence, always high severity
        if "glass" in detection_types and audio_detection["confidence"] > 0.8:
            severity = "high"
            
        return severity