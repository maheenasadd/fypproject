import os
import shutil
import uuid
from pathlib import Path
from fastapi import APIRouter, File, UploadFile, HTTPException, BackgroundTasks, Form
from fastapi.responses import JSONResponse, FileResponse
from typing import List, Optional

from app.model.number_plate_model import JobResults, JobStatus, VideoProcessResponse
from app.utils.video_process import process_video, get_job_status, delete_job


plate_router = APIRouter()

# Constants
UPLOAD_DIR = Path("uploads")
RESULTS_DIR = Path("results")

# Ensure directories exist
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

@plate_router.post("/detect-video", response_model=VideoProcessResponse)
async def detect_video(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(...),
    sample_rate: int = Form(1)
):
    """
    Upload a video to detect license plates
    - **video**: The video file to process
    - **sample_rate**: Process every nth frame (default: 1) - lower values give more accurate results but slower processing
    """
    # Validate sample rate
    if sample_rate < 1:
        raise HTTPException(status_code=400, detail="Sample rate must be at least 1")
    
    # Validate file type
    valid_extensions = ['.mp4', '.avi', '.mov', '.mkv']
    file_ext = os.path.splitext(video.filename)[1].lower()
    if file_ext not in valid_extensions:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported file format. Supported formats: {', '.join(valid_extensions)}"
        )
    
    # Generate a unique job ID
    job_id = str(uuid.uuid4())
    
    # Create directories if they don't exist
    UPLOAD_DIR.mkdir(exist_ok=True)
    job_results_dir = RESULTS_DIR / job_id
    job_results_dir.mkdir(parents=True, exist_ok=True)
    
    # Save uploaded video
    video_path = UPLOAD_DIR / f"{job_id}_{video.filename}"
    
    with open(video_path, "wb") as buffer:
        shutil.copyfileobj(video.file, buffer)
    
    print(f"Video saved to {video_path}, starting processing with sample rate {sample_rate}")
    
    # Start processing in background
    background_tasks.add_task(process_video, str(video_path), job_id, sample_rate)
    
    return {
        "job_id": job_id,
        "message": "Video processing started. Use the job_id to check status and retrieve results."
    }

@plate_router.get("/job-status/{job_id}", response_model=JobStatus)
async def get_job_status_api(job_id: str):
    """Get the status of a video processing job"""
    job = get_job_status(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    
    response = {
        "job_id": job_id,
        "status": job["status"],
        "processed_frames": job.get("processed_frames", 0),
        "total_frames": job.get("total_frames", 0),
        "detections_count": job.get("detections_count", 0),
        "error": job.get("error")
    }
    
    # Add progress percentage for better UX
    if job.get("total_frames", 0) > 0:
        response["progress_percentage"] = min(
            int(job.get("processed_frames", 0) / job.get("total_frames", 1) * 100), 
            100
        )
    
    return response

@plate_router.get("/results/{job_id}", response_model=JobResults)
async def get_job_results(job_id: str):
    """Get the results of a completed job"""
    job = get_job_status(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    
    if job["status"] != "completed":
        return {
            "job_id": job_id,
            "status": job["status"],
            "message": "Job is still processing or failed",
            "detection_count": job.get("detections_count", 0)
        }
    
    # Check if results exist
    result_path = RESULTS_DIR / job_id
    if not result_path.exists():
        raise HTTPException(status_code=404, detail="Results not found")
    
    # Get keyframes
    keyframes = [f"/results/{job_id}/{f.name}" for f in result_path.glob("frame_*.jpg")]
    
    # Get plate images
    plate_images = [f"/results/{job_id}/{f.name}" for f in result_path.glob("plate_*.jpg")]
    
    return {
        "job_id": job_id,
        "status": "completed",
        "output_video": f"/results/{job_id}/output.mp4",
        "detections_json": f"/results/{job_id}/detections.json",
        "detection_count": job["detections_count"],
        "keyframes": sorted(keyframes),
        "plate_images": sorted(plate_images),
        "detected_plates": job.get("plate_numbers", []),
        "unique_plates_count": job.get("total_unique_plates", 0)
    }

@plate_router.get("/download-video/{job_id}")
async def download_output_video(job_id: str):
    """Download the processed video with license plates detected"""
    job = get_job_status(job_id)
    if job is None or job["status"] != "completed":
        raise HTTPException(
            status_code=404, 
            detail="Processed video not found or processing not completed"
        )
    
    video_path = RESULTS_DIR / job_id / "output.mp4"
    if not video_path.exists():
        raise HTTPException(status_code=404, detail="Processed video file not found")
    
    return FileResponse(
        path=video_path, 
        filename=f"license_plate_detection_{job_id}.mp4",
        media_type="video/mp4"
    )

@plate_router.delete("/jobs/{job_id}")
async def delete_job_api(job_id: str):
    """Delete a job and its associated files"""
    job = get_job_status(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Delete uploaded video
    video_path = next(UPLOAD_DIR.glob(f"{job_id}_*"), None)
    if video_path and video_path.exists():
        os.remove(video_path)
    
    # Delete results directory
    result_path = RESULTS_DIR / job_id
    if result_path.exists():
        shutil.rmtree(result_path)
    
    # Remove from processing jobs
    delete_job(job_id)
    
    return {"message": f"Job {job_id} deleted successfully"}