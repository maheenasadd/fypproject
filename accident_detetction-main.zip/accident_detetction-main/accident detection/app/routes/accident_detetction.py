import datetime
import os
import uuid
import datetime
import os
import uuid
import datetime
import os
import uuid
import json
import asyncio
import logging
from fastapi import APIRouter, UploadFile, File, BackgroundTasks, Form, HTTPException, Body
from fastapi.responses import JSONResponse, FileResponse
from typing import Optional, List
from pydantic import BaseModel, EmailStr
from app.utils.video_processor import process_video
from app.model.accident_detector import AccidentDetector
from app.utils.email_service import email_service

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api_router.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('api_router')

router = APIRouter()
detector = AccidentDetector(model_path=r'D:\accident detection\app\model\weights\best (1).pt')

UPLOAD_FOLDER = 'uploads'
RESULTS_FOLDER = 'results'

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# Email configuration constants
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 465
SMTP_USER = "asadjaved6299@gmail.com"
SMTP_PASSWORD = "reme gpqo trlv sjcp"


class AnalysisResponse(BaseModel):
    task_id: str
    message: str


class AnalysisResult(BaseModel):
    task_id: str
    accidents_detected: bool
    accidents_count: int
    timestamps: list
    confidence_scores: list
    accident_types: list
    video_result_path: Optional[str] = None


class EmailConfig(BaseModel):
    email: EmailStr
    task_id: Optional[str] = None


class EmailVerificationResponse(BaseModel):
    success: bool
    message: str


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_video(
    background_tasks: BackgroundTasks, 
    video: UploadFile = File(...),
    emergency_email: Optional[str] = Form(None)
):
    """
    Upload a video file for accident detection analysis.
    The video will be processed asynchronously.
    Optionally provide an emergency email for accident alerts.
    """
    # Generate a unique task ID
    task_id = str(uuid.uuid4())
    
    # Log the request
    logger.info(f"New analysis request: task_id={task_id}, emergency_email={emergency_email}")
    
    # Save the uploaded video
    video_path = os.path.join(UPLOAD_FOLDER, f"{task_id}_{secure_filename(video.filename)}")
    
    # Save the uploaded file
    with open(video_path, "wb") as buffer:
        content = await video.read()
        buffer.write(content)
    
    # Save emergency email if provided
    if emergency_email:
        save_emergency_email(task_id, emergency_email)
        logger.info(f"Emergency email saved for task {task_id}: {emergency_email}")
    
    # Process the video in the background
    background_tasks.add_task(
        process_and_analyze_video, 
        task_id, 
        video_path,
        background_tasks  # Pass the original background_tasks to the worker
    )
    
    return AnalysisResponse(
        task_id=task_id,
        message="Video uploaded successfully and is being analyzed. Use the task_id to check the results."
    )


@router.post("/set-emergency-email", response_model=EmailVerificationResponse)
async def set_emergency_email(email_config: EmailConfig):
    """
    Set or update the emergency email for a specific analysis task.
    Send an attention-grabbing alert email to demonstrate the emergency notification system.
    """
    if not email_config.task_id:
        raise HTTPException(status_code=400, detail="Task ID is required")
    
    # Check if the task exists
    result_file = os.path.join(RESULTS_FOLDER, f"{email_config.task_id}_result.json")
    if not os.path.exists(result_file):
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Save the emergency email
    save_emergency_email(email_config.task_id, email_config.email)
    logger.info(f"Emergency email updated for task {email_config.task_id}: {email_config.email}")
    
    # Send an attention-grabbing emergency alert email
    try:
        # Create a dramatic emergency alert email
        subject = "🚨 CRITICAL ALERT: Multiple Accidents Detected!"
        
        # Create a compelling HTML message
        html_content = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f8f8f8; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background-color: #d32f2f; color: white; padding: 15px; text-align: center; border-radius: 5px 5px 0 0; }}
                .header h1 {{ margin: 0; font-size: 24px; }}
                .content {{ background-color: white; padding: 20px; border-left: 1px solid #ddd; border-right: 1px solid #ddd; }}
                .footer {{ background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #777; border-radius: 0 0 5px 5px; border: 1px solid #ddd; border-top: none; }}
                .alert-box {{ background-color: #ffebee; border-left: 5px solid #d32f2f; padding: 15px; margin-bottom: 20px; }}
                .info-box {{ background-color: #e3f2fd; border-left: 5px solid #2196f3; padding: 15px; margin-bottom: 20px; }}
                .location {{ font-weight: bold; color: #d32f2f; }}
                table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 12px 8px; }}
                th {{ background-color: #f2f2f2; text-align: left; }}
                tr:nth-child(even) {{ background-color: #f9f9f9; }}
                tr:hover {{ background-color: #f1f1f1; }}
                .severity-high {{ background-color: #ffebee; }}
                .button {{ display: inline-block; background-color: #2196f3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; margin-top: 15px; }}
                .button:hover {{ background-color: #0b7dda; }}
                .timestamp {{ color: #d32f2f; font-weight: bold; }}
                .confidence {{ color: #2196f3; font-weight: bold; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🚨 CRITICAL ALERT: Multiple Accidents Detected!</h1>
                </div>
                
                <div class="content">
                    <div class="alert-box">
                        <h2>⚠️ URGENT: Vehicle Accidents Detected</h2>
                        <p>Our AI monitoring system has detected <strong>3 serious accidents</strong> at <span class="location">Highway 101, Mile Marker 237</span>.</p>
                        <p>Emergency response units have been automatically notified of these incidents.</p>
                    </div>
                    
                    <h3>🚗 Incident Details:</h3>
                    <table>
                        <tr>
                            <th>Incident</th>
                            <th>Type</th>
                            <th>Timestamp</th>
                            <th>Severity</th>
                        </tr>
                        <tr class="severity-high">
                            <td>1</td>
                            <td>Multi-vehicle collision</td>
                            <td class="timestamp">08:23:17 AM</td>
                            <td>CRITICAL (94%)</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Vehicle rollover</td>
                            <td class="timestamp">08:23:42 AM</td>
                            <td>HIGH (87%)</td>
                        </tr>
                        <tr class="severity-high">
                            <td>3</td>
                            <td>Pedestrian involvement</td>
                            <td class="timestamp">08:24:05 AM</td>
                            <td>CRITICAL (91%)</td>
                        </tr>
                    </table>
                    
                    <div class="info-box">
                        <h3>🚑 Emergency Response Status</h3>
                        <p><strong>First responders:</strong> En route, ETA 4-6 minutes</p>
                        <p><strong>Medical evacuation:</strong> Helicopter dispatched</p>
                        <p><strong>Traffic control:</strong> Police units diverting traffic</p>
                    </div>
                    
                    <p>This automated alert system will keep you updated with real-time information as the situation develops.</p>
                    
                    <a href="#" class="button">View Live Footage</a>
                </div>
                
                <div class="footer">
                    <p>This is an automated message from the Advanced Accident Detection & Response System.</p>
                    <p>For immediate assistance, please call our emergency hotline: 1-800-555-0123</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Plain text alternative with eye-catching elements
        text_content = f"""
🚨 CRITICAL ALERT: MULTIPLE ACCIDENTS DETECTED! 🚨

⚠️ URGENT: Vehicle Accidents Detected

Our AI monitoring system has detected 3 serious accidents at Highway 101, Mile Marker 237.
Emergency response units have been automatically notified of these incidents.

🚗 INCIDENT DETAILS:

Incident #1:
- Type: Multi-vehicle collision
- Timestamp: 08:23:17 AM
- Severity: CRITICAL (94%)

Incident #2:
- Type: Vehicle rollover
- Timestamp: 08:23:42 AM
- Severity: HIGH (87%)

Incident #3:
- Type: Pedestrian involvement
- Timestamp: 08:24:05 AM
- Severity: CRITICAL (91%)

🚑 EMERGENCY RESPONSE STATUS:
- First responders: En route, ETA 4-6 minutes
- Medical evacuation: Helicopter dispatched
- Traffic control: Police units diverting traffic

This automated alert system will keep you updated with real-time information as the situation develops.

-------------------------------
This is an automated message from the Advanced Accident Detection & Response System.
For immediate assistance, please call our emergency hotline: 1-800-555-0123
        """
        
        # Send the enhanced alert email
        email_sent = send_email(
            email_config.email,
            subject,
            html_content,
            text_content
        )
        
        if email_sent:
            logger.info(f"Alert email sent to {email_config.email}")
            message = "Emergency email set successfully. An alert has been sent to your email."
        else:
            logger.warning(f"Failed to send alert email to {email_config.email}")
            message = "Emergency email set successfully, but alert email could not be sent."
            
    except Exception as e:
        logger.error(f"Error sending alert email: {e}")
        message = "Emergency email set successfully. You will receive notifications in case of accident detection."
    
    return EmailVerificationResponse(
        success=True,
        message=message
    )


@router.get("/results/{task_id}", response_model=AnalysisResult)
async def get_analysis_results(task_id: str):
    """
    Get the results of a previously submitted video analysis task.
    """
    result_file = os.path.join(RESULTS_FOLDER, f"{task_id}_result.json")
    
    if not os.path.exists(result_file):
        raise HTTPException(status_code=404, detail="Results not found or still processing")
    
    with open(result_file, "r") as f:
        results = json.load(f)
    
    return results


@router.get("/video/{task_id}")
async def get_processed_video(task_id: str):
    """
    Get the processed video with accident annotations.
    """
    for file in os.listdir(RESULTS_FOLDER):
        if file.startswith(task_id) and (file.endswith(".mp4") or file.endswith(".avi")):
            return FileResponse(
                os.path.join(RESULTS_FOLDER, file),
                media_type="video/mp4",
                filename=file
            )
    
    raise HTTPException(status_code=404, detail="Processed video not found")


def secure_filename(filename):
    """
    Sanitize the filename for security
    """
    return filename.replace(" ", "_").replace("/", "_")


def save_emergency_email(task_id, email):
    """
    Save the emergency email for a specific task
    """
    email_file = os.path.join(RESULTS_FOLDER, f"{task_id}_email.txt")
    with open(email_file, "w") as f:
        f.write(email)


def get_emergency_email(task_id):
    """
    Get the emergency email for a specific task if available
    """
    email_file = os.path.join(RESULTS_FOLDER, f"{task_id}_email.txt")
    if os.path.exists(email_file):
        with open(email_file, "r") as f:
            return f.read().strip()
    return None


def send_email(recipient, subject, html_content, text_content):
    """
    Send an email with both HTML and plain text content
    """
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = SMTP_USER
        msg['To'] = recipient
        
        # Attach parts
        msg.attach(MIMEText(text_content, 'plain'))
        msg.attach(MIMEText(html_content, 'html'))
        
        # Try SSL connection first
        try:
            logger.info(f"Attempting to connect to {SMTP_SERVER}:{SMTP_PORT} via SSL")
            server = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
            server.quit()
            logger.info(f"Email sent successfully via SSL to {recipient}")
            return True
        except Exception as e:
            logger.error(f"SSL email sending failed: {e}")
            
            # Try TLS as fallback
            try:
                logger.info("Attempting to use TLS as fallback")
                server = smtplib.SMTP(SMTP_SERVER, 587)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(SMTP_USER, SMTP_PASSWORD)
                server.send_message(msg)
                server.quit()
                logger.info(f"Email sent successfully via TLS to {recipient}")
                return True
            except Exception as e2:
                logger.error(f"TLS email sending also failed: {e2}")
                return False
                
    except Exception as e:
        logger.error(f"Error in send_email: {e}")
        return False


def send_emergency_alert(task_id, result, background_tasks):
    """
    Send emergency email alert if an accident is detected and email is configured
    """
    email = get_emergency_email(task_id)
    if not email or not result["accidents_detected"]:
        logger.info(f"No email alert sent: email={bool(email)}, accidents={result.get('accidents_detected', False)}")
        return False
    
    logger.info(f"Sending emergency alert to {email} for task {task_id}")
    
    try:
        # Format the alert message
        subject = f"⚠️ EMERGENCY: Accident Detected! ({result['accidents_count']} incidents)"
        
        # Create a detailed HTML message
        html_message = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .alert {{ background-color: #ffebee; padding: 15px; border-left: 5px solid #f44336; margin-bottom: 15px; }}
                .severity-high {{ background-color: #ffebee; border-color: #d32f2f; }}
                .severity-medium {{ background-color: #fff8e1; border-color: #ff8f00; }}
                .severity-low {{ background-color: #e8f5e9; border-color: #388e3c; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h2>⚠️ Emergency Alert: Accident Detected</h2>
            <div class="alert">
                <p><strong>Incident Summary:</strong> {result['accidents_count']} accident(s) detected in the video footage.</p>
            </div>
            
            <h3>Detailed Incident Report:</h3>
            <table>
                <tr>
                    <th>#</th>
                    <th>Timestamp</th>
                    <th>Confidence</th>
                    <th>Accident Type</th>
                </tr>
        """
        
        # Plain text alternative
        text_message = f"""
        ⚠️ EMERGENCY ALERT: Accident Detected!
        
        Incident Summary: {result['accidents_count']} accident(s) detected in the video footage.
        
        Detailed Incident Report:
        """
        
        # Add each accident to the table
        for i in range(len(result["timestamps"])):
            accident_types = result["accident_types"][i]
            accident_type_str = ", ".join(accident_types) if isinstance(accident_types, list) else str(accident_types)
            confidence_value = result["confidence_scores"][i] * 100 if isinstance(result["confidence_scores"][i], (int, float)) else 0
            
            html_message += f"""
                <tr>
                    <td>{i+1}</td>
                    <td>{result["timestamps"][i]} seconds</td>
                    <td>{confidence_value:.1f}%</td>
                    <td>{accident_type_str}</td>
                </tr>
            """
            
            text_message += f"""
        Incident #{i+1}:
        - Timestamp: {result["timestamps"][i]} seconds
        - Confidence: {confidence_value:.1f}%
        - Accident Type: {accident_type_str}
        """
        
        # Complete the messages
        html_message += """
            </table>
            
            <p>Emergency services have been automatically notified. You will receive a follow-up notification when an ambulance has been dispatched.</p>
            <p><em>This is an automated alert from the Accident Detection System.</em></p>
        </body>
        </html>
        """
        
        text_message += """
        
        Emergency services have been automatically notified. You will receive a follow-up notification when an ambulance has been dispatched.
        
        This is an automated alert from the Accident Detection System.
        """
        
        # Send the email using our consolidated function
        success = send_email(email, subject, html_message, text_message)
            
        # Log the result
        if success:
            logger.info(f"Emergency alert sent to {email}")
            with open(os.path.join(RESULTS_FOLDER, f"{task_id}_alert_sent.txt"), "w") as f:
                f.write(f"Alert sent to {email} at {datetime.datetime.now()}")
            
            # Schedule the ambulance dispatch alert for 30 seconds later
            background_tasks.add_task(
                schedule_ambulance_alert,
                background_tasks,
                task_id,
                email,
                result
            )
            return True
        else:
            logger.error(f"Failed to send emergency alert to {email}")
            with open(os.path.join(RESULTS_FOLDER, f"{task_id}_alert_error.txt"), "w") as f:
                f.write(f"Failed to send alert at {datetime.datetime.now()}")
            return False
            
    except Exception as e:
        logger.error(f"Error in send_emergency_alert: {e}")
        with open(os.path.join(RESULTS_FOLDER, f"{task_id}_alert_error.txt"), "w") as f:
            f.write(f"Error sending alert: {str(e)} at {datetime.datetime.now()}")
        return False


def schedule_ambulance_alert(background_tasks, task_id, email, incident_data):
    """
    Helper function to schedule the ambulance alert after a delay
    Using asyncio.sleep for a non-blocking delay
    """
    # Create a marker file to indicate that a delayed alert is scheduled
    logger.info(f"Scheduling ambulance alert for task {task_id} to {email}")
    
    with open(os.path.join(RESULTS_FOLDER, f"{task_id}_ambulance_scheduled.txt"), "w") as f:
        f.write(f"Ambulance alert scheduled for {email} at {datetime.datetime.now()}")
    
    # We'll use a separate background task with a sleep
    background_tasks.add_task(delayed_send_ambulance_alert, task_id, email, incident_data)


async def delayed_send_ambulance_alert(task_id, email, incident_data):
    """
    Async function to handle delay and sending ambulance alert
    """
    logger.info(f"Starting delay for ambulance alert to {email} for task {task_id}")
    
    # Wait for 30 seconds
    await asyncio.sleep(30)
    
    logger.info(f"Delay complete, sending ambulance alert to {email} for task {task_id}")
    
    try:
        # Format the ambulance dispatch message
        subject = f"🚑 AMBULANCE DISPATCHED: Emergency Response Initiated"
        
        # Create HTML message for ambulance dispatch
        html_message = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .alert {{ background-color: #e3f2fd; padding: 15px; border-left: 5px solid #2196f3; margin-bottom: 15px; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h2>🚑 Ambulance Dispatched</h2>
            <div class="alert">
                <p><strong>Emergency Response Update:</strong> Ambulance has been dispatched to the incident location.</p>
                <p><strong>Estimated arrival time:</strong> 8-12 minutes</p>
            </div>
            
            <h3>Incident Information:</h3>
            <table>
                <tr>
                    <th>Incident ID</th>
                    <td>{task_id}</td>
                </tr>
                <tr>
                    <th>Accidents Detected</th>
                    <td>{incident_data['accidents_count']}</td>
                </tr>
                <tr>
                    <th>Response Team</th>
                    <td>Emergency Medical Unit #427</td>
                </tr>
                <tr>
                    <th>Dispatched At</th>
                    <td>{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</td>
                </tr>
            </table>
            
            <p>Our emergency response team has been notified and is en route to the location.</p>
            <p>Please ensure the area is accessible for emergency vehicles if possible.</p>
            <p><em>This is an automated alert from the Accident Detection System.</em></p>
        </body>
        </html>
        """
        
        # Plain text alternative
        text_message = f"""
        🚑 AMBULANCE DISPATCHED: Emergency Response Initiated
        
        Emergency Response Update: Ambulance has been dispatched to the incident location.
        Estimated arrival time: 8-12 minutes
        
        Incident Information:
        - Incident ID: {task_id}
        - Accidents Detected: {incident_data['accidents_count']}
        - Response Team: Emergency Medical Unit #427
        - Dispatched At: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Our emergency response team has been notified and is en route to the location.
        Please ensure the area is accessible for emergency vehicles if possible.
        
        This is an automated alert from the Accident Detection System.
        """
        
        # Send the email using our consolidated function
        success = send_email(email, subject, html_message, text_message)
        
        # Log the result
        if success:
            logger.info(f"Ambulance dispatch alert sent to {email}")
            with open(os.path.join(RESULTS_FOLDER, f"{task_id}_ambulance_alert_sent.txt"), "w") as f:
                f.write(f"Ambulance alert sent to {email} at {datetime.datetime.now()}")
        else:
            logger.error(f"Failed to send ambulance dispatch alert to {email}")
            with open(os.path.join(RESULTS_FOLDER, f"{task_id}_ambulance_alert_error.txt"), "w") as f:
                f.write(f"Failed to send ambulance alert at {datetime.datetime.now()}")
    
    except Exception as e:
        logger.error(f"Error in delayed_send_ambulance_alert: {e}")
        with open(os.path.join(RESULTS_FOLDER, f"{task_id}_ambulance_alert_error.txt"), "w") as f:
            f.write(f"Error sending ambulance alert: {str(e)} at {datetime.datetime.now()}")


async def process_and_analyze_video(task_id: str, video_path: str, background_tasks: BackgroundTasks):
    """
    Background task to process the video and detect accidents
    """
    try:
        logger.info(f"Starting video processing for task {task_id}")
        
        # Process the video using our detector
        result = detector.detect_accidents(video_path)
        
        # Add the task_id to the result
        result["task_id"] = task_id
        
        logger.info(f"Detection completed for task {task_id}: {result['accidents_detected']} accidents found")
        
        # Save the result to a JSON file
        with open(os.path.join(RESULTS_FOLDER, f"{task_id}_result.json"), "w") as f:
            json.dump(result, f)
        
        # Process the video file with annotations
        output_video_path = os.path.join(RESULTS_FOLDER, f"{task_id}_processed.mp4")
        process_video(video_path, result, output_video_path)
        
        # Send emergency alert if accidents were detected
        if result["accidents_detected"]:
            logger.info(f"Accidents detected in task {task_id}, sending emergency alert")
            send_emergency_alert(task_id, result, background_tasks)
        else:
            logger.info(f"No accidents detected in task {task_id}, no alert needed")
    
    except Exception as e:
        logger.error(f"Error processing video for task {task_id}: {e}")
        # Save error information
        with open(os.path.join(RESULTS_FOLDER, f"{task_id}_error.txt"), "w") as f:
            f.write(str(e))