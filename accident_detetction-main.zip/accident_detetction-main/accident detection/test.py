# Save as test_imports.py
import numpy
print(f"NumPy version: {numpy.__version__}")

import cv2
print(f"OpenCV version: {cv2.__version__}")

print("Both imports successful!")